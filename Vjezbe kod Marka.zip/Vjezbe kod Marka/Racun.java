package osmanedelja;

public class Racun implements Trosak {

	
	private String opis;
	private float iznos;
	private float pdv;

	
	public Racun () {
		this (null,0,0);
		}
	
	public Racun(String opis, float iznos, float pdv) {
		super();
		this.setOpis(opis);
		this.setIznos(iznos);
		this.setPdv(pdv);
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public float getIznos() {
		return iznos;
	}
	public void setIznos(float iznos) {
		if(iznos>=0)//provjeravamo je li iznos veci od 0 
		this.iznos = iznos;
	}

	public float getPdv() {
		return pdv;
	}


	public void setPdv(float pdv) {
		if(pdv>=0)
		this.pdv = pdv;
	}


	@Override
	public String toString() {
		return "Racun [opis=" + opis + ", iznos=" + iznos + ", pdv=" + pdv + "]";
	}

	@Override
	public float getIznosTrosaka() {
		return this.getIznos() + getPdv();
		
	}

}
