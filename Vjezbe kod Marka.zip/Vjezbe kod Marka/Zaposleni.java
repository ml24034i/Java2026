package osmanedelja;

public abstract class Zaposleni implements Trosak {

	
	private String ime;
	private String prezime;
	private int brojGodinaStaza;
	
	public abstract float obracunPlte();                  
	
	
	
	public Zaposleni(){
	this (null,null,0);// Korištena ključna riječ "this" da proslijedi podrazumijevane vrijednosti
	}
	
	public Zaposleni(String ime, String prezime, int brojGodinaStza) {
		super();
		this.setIme(ime);
		this.setPrezime(prezime);
		this.setBrojGodinaStaza(brojGodinaStaza);
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public int getBrojGodinaStaza() {
		return brojGodinaStaza;
	}

	public void setBrojGodinaStaza(int brojGodinaStza) {
		if ( brojGodinaStaza<=0) {
				}else {
			this.brojGodinaStaza = 0;
		}
	}

	public float getIznosTrosaka() {
		return 0;
	}

}
