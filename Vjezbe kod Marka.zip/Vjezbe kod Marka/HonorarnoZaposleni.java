package osmanedelja;


public class HonorarnoZaposleni extends Zaposleni {

	private int  brojSati;
	private  float cijenaSata;
	
	
	
	public HonorarnoZaposleni () {
		this (null,null,0,0,0);
		
	}
	
	
	public HonorarnoZaposleni( String ime, String prezime, int brojSati, float cijenaSati, float f) {
		super();
		this.setBrojSati(brojSati);
		this.setCijenaSata(cijenaSata);
	}


	public float getBrojSati() {
		return brojSati;
	}


	public void setBrojSati(int brojSati) {
		if (brojSati>=0)
		this.brojSati = brojSati;
	}

	public float getCijenaSata() {
		return cijenaSata;
	}
	public void setCijenaSata(float cijenaSata) {
		if(cijenaSata>=0)
		this.cijenaSata = cijenaSata;
	}
	



	@Override
	public String toString() {
		return "HonorarnoZaposleni [brojSati=" + brojSati + ", cijenaSata=" + cijenaSata + "]";
	}

	public float iznosTroska () {
		return this.obracunPlte();
	}

	@Override
	public float obracunPlte() {
		return this.getCijenaSata()*this.brojSati;
	}

}
