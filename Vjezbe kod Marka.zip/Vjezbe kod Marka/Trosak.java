package osmanedelja;

public  interface Trosak {

	 float getIznosTrosaka();
	
}
