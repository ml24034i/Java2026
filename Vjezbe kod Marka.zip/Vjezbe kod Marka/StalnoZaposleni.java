package osmanedelja;

public class StalnoZaposleni extends Zaposleni {
	
	private float koficijent;
	private static float osnovica;
	
	
	public StalnoZaposleni() {
		this ( null,null,0,0);
		
	}
	

	public StalnoZaposleni( String ime, String prezime, float koficijent, float f) {
		super();
		this.setKoficijent(koficijent);
	}

	public float getKoficijent() {
		return koficijent;
	}

	public void setKoficijent(float koficijent) {
		this.koficijent = koficijent;
	}


	public static float getOsnovica() {
		return osnovica;
	}

	public static void setOsnovica(float osnovica) {
		StalnoZaposleni.osnovica = osnovica;
	}

public float getIznosTroska() {
	return this.obracunPlte();
}



	@Override
	public float obracunPlte() {
		return StalnoZaposleni.getOsnovica() * this.getKoficijent() + 10 * getBrojGodinaStaza();//StalnoZaposleni.getOsnovica() * this.getKoficijent(): Uzima se osnovica plate (koja je zajednička za sve stalno zaposlene jer je static) i množi se sa koeficijentom specifičnim za tog radnika (this.getKoficijent()).
//+ 10 * this.getBrojGodinaStza(): Na taj osnovni dio dodaje se bonus na staž – na primjer, 10 (novčanih jedinica) puta ukupan broj godina staža koji radnik ima (this.getBrojGodinaStza()).
	
		
	}


	@Override
	public String toString() {
		return "StalnoZaposleni [koficijent=" + koficijent + ", getKoficijent()=" + getKoficijent()
				+ ", getIznosTroska()=" + getIznosTroska() + ", obracunPlte()=" + obracunPlte() + ", getIme()="
				+ getIme() + ", getPrezime()=" + getPrezime() + ", getBrojGodinaStaza()=" + getBrojGodinaStaza()
				+ ", getIznosTrosaka()=" + getIznosTrosaka() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}
