package osmanedelja;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
	
	
	ArrayList <Zaposleni> zaposleni = new ArrayList<Zaposleni>();
	zaposleni.add(new StalnoZaposleni("Janko", "Jankovic", 10,5.2f));
	zaposleni.add(new StalnoZaposleni("Marija", "Mirkovic", 2, (float)6.4));
	zaposleni.add(new HonorarnoZaposleni("Emir", "Jakic", 1, 23, (float)15));
		
	float ukupnaPlata = 0;
		for (Zaposleni z: zaposleni) {
		ukupnaPlata += z.obracunPlte();
		}
	System.out.printf("Ukupna plata zaposlenih: %.2f EUR.\n", ukupnaPlata);
	
	ArrayList <Trosak> troskovi = new ArrayList <Trosak>();
	troskovi.add(new StalnoZaposleni("Branka", "Jankovic", 4, (float)7.4));
	troskovi.add(new HonorarnoZaposleni("Maja", "Bakrac",1, 34, (float)21));
	troskovi.add(new StalnoZaposleni("Neno", "Bakrac", 2, (float)4.4));
	troskovi.add(new Racun("Kinder Bueno", 1, (float)0.21));
	
	float ukupniTrosak = 0;
    for (Trosak t : troskovi) {
        ukupniTrosak += t.getIznosTrosaka();
        
	System.out.printf("Ukupni troskovi: %.2f EUR.\n", ukupniTrosak);

}
}
}